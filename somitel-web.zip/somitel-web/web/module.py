from firebase_admin import auth,db
from flask import session
from web import app   
def register_user(email, password, username, address, phone):
    try:
        # Create a new Firebase user
        new_firebase_user = auth.create_user(
            email=email,
            password=password
        )
        
        # Generate a new Firebase UID
        new_uid = new_firebase_user.uid
        
        # Add user data to the Realtime Database
        user_data = {
            "address": address,
            "email": email,
            "phone": phone,
            "username": username,
            "role":'user'
        }
        
        user_ref = db.reference('users/{uid}'.format(uid=new_uid))
        user_ref.set(user_data)
        
        return {
            'success': True,
            'user_id':new_uid,
            'message': 'User registered successfully!'
        }
    except Exception as e:
        return {
            'success': False,
            'message': str(e)
        }

def clear_session_except_language():
    language = session.get('language')  # Store the language value
    session.clear()  # Clear all session variables
    session['language'] = language  # Restore the language value
    
@app.before_request
def set_default_language():
    if 'language' not in session:
        session['language'] = 'en'    
