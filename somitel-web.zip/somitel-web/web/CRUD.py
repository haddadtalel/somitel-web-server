
import requests
from web import app , prod , gridfs , LANGUAGES
from flask import redirect,render_template,session,Request,request ,url_for
from bson import ObjectId
import base64
from .auth import login_required ,Admin
import firebase_admin
from firebase_admin import credentials, auth ,db
from .module import register_user



@app.route('/addPro', methods=['GET', 'POST'])
@Admin
@login_required
def addPro():
    if request.method=="POST":  
     if 'image' in request.files:
        image = request.files['image']
        name = request.form.get('Pname')
        id = gridfs.put(image, content_type=image.content_type, filename=name)
        
        prod.insert_one({
            'id': id,
            'Pnumber': request.form['Pnumber'],
            'Pname': request.form['Pname'],
            'price': request.form['price'],
            'quantity': request.form['quantity'],
            'product_detail' : request.form['product_detail'] 
        })
    return redirect(url_for('viewproduct'))


@app.route('/deleteproduct/<productid>', methods=['POST'])
@Admin
@login_required
def delete_product(productid):
    
    product = prod.find_one({'Pnumber': productid})
       
    prod.delete_one({'Pnumber': productid})
  
    gridfs.delete(product['id'])
    return  redirect(url_for('viewproduct'))




@app.route('/updateproduct', methods=['GET', 'POST'])
@Admin
@login_required
def update_product():
    if request.method == 'POST':
        
        product_id_obj = request.form['Pnumber']
        image = request.files['image']
        id = gridfs.put(image, content_type=image.content_type, filename=product_id_obj)        
        updated_data = {
            'id': id,
            'Pname': request.form['Pname'],
            'Pnumber': request.form['Pnumber'],
            'price': request.form['price'],
            'quantity': request.form['quantity'],
        }

        # Update the product with the given _id
        prod.update_one({'Pnumber': product_id_obj}, {'$set': updated_data})

        # Redirect back to the dashboard or any other desired route
        return redirect(url_for('viewproduct'))

 
    
    
@app.route('/updatpro', methods=['GET', 'POST'])
@login_required
def updatpro(): 
    products = prod.find({'Pnumber':request.form['prodID']})
    products_data = []
    for product in products:
        if 'id' in product:
            image_data = gridfs.get(product['id'])
            base64_data = base64.b64encode(image_data.read()).decode('utf-8')
            product_data = {
                'image_data': base64_data,
                'Pname': product['Pname'],
                'Pnumber': product['Pnumber'],
                'price': product['price'],
                'quantity': product['quantity'],
        }
            products_data.append(product_data)

    return render_template('update.html', products=products_data) 


@app.route('/signin', methods=['GET', 'POST'])
def signin():  
    if request.method == 'POST':
        email = request.form['email']
        pw = request.form['password']
        Cpw = request.form['ConfPassword']
        if pw != Cpw:
            passwordnotmatch = 'Password does not match. Please confirm your password.'
            return render_template('sign_up.html', pnm=passwordnotmatch)

        username = request.form['username']
        phone = request.form['phone']
        address = request.form['Address']

        result = register_user(email, pw, username, phone, address)
        if result['success']:
            # User registration successful, store session data
            session['userid'] = result['user_id']
            session['email'] = email
            session['username'] = username
            return redirect(url_for('home'))
        else:
            return render_template('sign_up.html', errorMsg=result['message'], languages=LANGUAGES)

    return redirect(url_for('home'))

@app.route('/update_profile', methods=['POST'])
@login_required
def update_profile():
    if request.method == 'POST':
        uid = session.get('userid')
        role = session.get('role')
        new_username = request.form['username']
        new_email = request.form['email']
        new_phone = request.form['phone']
        new_address = request.form['Address']
        
        user_data = {
            'username': new_username,
            'email': new_email,
            'phone': new_phone,
            'address': new_address,
            'role': role,
        }
        user_ref = db.reference('users/{uid}'.format(uid=uid))
        user_ref.set(user_data)
        auth.update_user(uid, display_name=new_username, email=new_email)
        
        session['username'] = new_username
        session['email'] = new_email
        return redirect(url_for('profile'))
    return redirect(url_for('home'))

@app.route('/change_password', methods=['POST', 'GET'])
@login_required
def change_password():
    if request.method == 'POST':
        user_id = session.get('userid')
        email = session.get('email')
        current_password = request.form['current_password']
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']

        if confirm_password != new_password:
            error_message = 'New password does not match confirmation.'
            return render_template('update_password.html', error_message=error_message)

        try:
            verify_url = f'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyDF5MF2wqFshOuERmLGZWsUtYyGxgEu4iE'
            payload = {
                'email': email,
                'password': current_password,
                'returnSecureToken': True
            }
            response = requests.post(verify_url, json=payload)
            data = response.json()
            if 'idToken' in data:
                user = auth.get_user(user_id)
                auth.update_user(user.uid, password=new_password)
                return redirect(url_for('dashboard'))
            else:
                error_message = 'Invalid current password.'
                return render_template('update_password.html', error_message=error_message)
        except:
            error_message = 'An error occurred.'
            return render_template('update_password.html', error_message=error_message)
    return redirect(url_for('home'))

@app.route('/delete_user', methods=['POST'])
@login_required
def delete_user():
    user_id = session.get('userid')
    try:
        auth.delete_user(user_id)
        user_ref = db.reference('users/{uid}'.format(uid=user_id))
        user_ref.delete()
        session.clear()
        return redirect(url_for('home'))
    except Exception as e:
        error_message = 'An error occurred while deleting the user.'
        return render_template('profile.html', error_message=error_message, languages=LANGUAGES)
