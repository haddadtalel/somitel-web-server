import os
from flask import Flask , session
from pymongo import MongoClient
from pymongo.server_api import ServerApi
from gridfs import GridFS
import firebase_admin
from firebase_admin import credentials, auth

cred_path = os.path.abspath('web/somitel-cevcret.json')
cred = credentials.Certificate(cred_path)

firebase_admin.initialize_app(cred, {
    'databaseURL': "https://somitel-7715d-default-rtdb.firebaseio.com/"
    
})
LANGUAGES = {
    'en': 'English',
    'fr': 'France',
}

 

app = Flask(__name__)
app.config["SECRET_KEY"] = 'Somitel'


Mydburl =  os.environ.get('MONGO_URI')
Mydb = MongoClient(Mydburl, server_api=ServerApi('1'))


product = Mydb['product']
prod = product['prod']

orders = Mydb['orders']
order = orders['order']


cart = Mydb['product_cart']
cart_collection = cart['cart_collection']

gridfs = GridFS(product)



from web import route
from web import CRUD
from web import auth
from web import views
from web import shop
