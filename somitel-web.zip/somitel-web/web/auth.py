from functools import wraps
from flask import  render_template, request,redirect, url_for , session 
from web import app , LANGUAGES
from .module import clear_session_except_language
import requests
from firebase_admin import auth , db
 
# Decorator: login_required
def login_required(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        if 'userid' not in session:  # Update this line
            autherr = 'you are not authorized please login and try again '
            return redirect(url_for('login')) 
        return function(*args, **kwargs)
    return wrapper

# Decorator: Admin
def Admin(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        if session.get('role') != 'Admin':  # Update this line
            autherr = 'You are not authorized. Please log in and try again.'
            return redirect(url_for('login'))
        return function(*args, **kwargs)
    return wrapper





@app.route('/Login', methods=['GET', 'POST'])
def Login():
    if request.method == 'POST':
        email = request.form['username']
        password = request.form['password']
        
        url = " https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyDF5MF2wqFshOuERmLGZWsUtYyGxgEu4iE"

        data = {
            "email": email,
            "password": password,
            "returnSecureToken": True
        }
        
        result = requests.post(url, json=data)
        
        if result.ok:
            user_rec = result.json()
            uid = user_rec['localId']# Replace with your Realtime Database URL
            user_ref = db.reference('users/{uid}'.format(uid=uid))
            user_data = user_ref.get()
            session['username'] = user_rec['displayName']
            session['userid'] = uid
            session['email'] = user_rec['email']
            session['role']= user_data['role']
            session['address']= user_data['address']
            session['phone']= user_data['phone']
            return redirect(url_for('viewShop'))
        else:
            error_message = 'Invalid email or password.'
            return render_template('login.html', errmsg=error_message, languages=LANGUAGES)
    
    return render_template('login.html')



@app.route('/logout')
@login_required
def logout():
    clear_session_except_language()
    return redirect(url_for('login'))
