from datetime import datetime
from flask import render_template, session , redirect,url_for,request
from web import app ,prod , gridfs,order , cart_collection ,LANGUAGES
import base64
from .auth import login_required , Admin
from firebase_admin import db,auth 

@app.route('/viewproduct', methods=['GET', 'POST'])
@login_required
@Admin
def viewproduct():
    products = prod.find()
    products_data = []
    for product in products:
        if 'id' in product:
            image_data = gridfs.get(product['id'])
            base64_data = base64.b64encode(image_data.read()).decode('utf-8')
            product_data = {
                'image_data': base64_data,
                'Pname': product['Pname'],
                'Pnumber': product['Pnumber'],
                'price': product['price'],
                'quantity': product['quantity'],
        }
            products_data.append(product_data)

    return render_template('view.html', products=products_data, languages=LANGUAGES)

@app.route('/viewShop', methods=['GET', 'POST'])
def viewShop():
    products = prod.find()
    products_data = []
    for product in products:
        product_data = {
            'Pname': product['Pname'],
            'Pnumber': product['Pnumber'],
            'price': product['price'],
            'quantity': product['quantity'],
            '_id': str(product['_id'])  # Convert the ObjectId to a string
        }
        if 'id' in product:
            try:
                image_data = gridfs.get(product['id'])
                base64_data = base64.b64encode(image_data.read()).decode('utf-8')
                product_data['image_data'] = base64_data
            except gridfs.errors.NoFile:
                product_data['image_data'] = None

        products_data.append(product_data)
        message = request.args.get('msg', None)
    return render_template('shop.html', products=products_data,message=message, languages=LANGUAGES)


@app.route('/view_cart', methods=['GET', 'POST'])
@login_required
def view_cart():
    email = session.get('email')
    cart_items = cart_collection.find({'email': email})
    cart_items_data = []
    total_price = 0 
    for cart_item in cart_items:       
        product_price = int(cart_item['product_price'])
        quantity = int(cart_item['quantity'])
        item_price = product_price * quantity
        cart_items_data.append({
            'product_id': cart_item['product_id'],
            'product_name': cart_item['product_name'],
            'product_price': product_price,
            'quantity': quantity,
            'item_price': item_price  
        })

        total_price += item_price  
    if not cart_items_data:
        return redirect (url_for('viewShop'))
    return render_template('viewCart.html', cart_items=cart_items_data, total_price=total_price, languages=LANGUAGES)

@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    uid = session['userid']
    user_ref = db.reference('users/{uid}'.format(uid=uid))
    user_data = user_ref.get()
    return render_template('dashboard.html', user_data=user_data , languages=LANGUAGES)

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    uid = session['userid']
    if uid:
        user_ref = db.reference('users/{uid}'.format(uid=uid))
        user_data = user_ref.get()
        return render_template('profile.html', user_data=user_data, languages=LANGUAGES)
    else:
        return "User ID not found in session"
 


@app.route('/orders', methods=['GET', 'POST'])
@login_required
@Admin
def orders():
    all_orders = order.find()
    order_data = []
    if session:
        email = session.get('email')
    for order_item in all_orders:
        order_date = order_item.get('order_date')

        if order_date is not None:
            formatted_order_date = datetime.strftime(order_date, "%Y-%m-%d %H:%M")

            order_data_item = {
                'product_id': order_item.get('product_id', ''), 
                'product_name': order_item.get('product_name', ''),
                'product_price': order_item.get('product_price', ''),
                'quantity': order_item.get('quantity', ''),
                'username': order_item.get('username', ''),
                'email': order_item.get('email', ''),
                'phone': order_item.get('phone', ''),  
                'address': order_item.get('address', ''),
                'order_date': formatted_order_date
            }
            order_data.append(order_data_item)
    return render_template('orders.html', orders=order_data, languages=LANGUAGES)