from flask import render_template, request, flash, redirect ,url_for , session  , send_file ,make_response,Response , send_file
from web import app ,prod , gridfs , order , cart_collection , LANGUAGES
from datetime import datetime
from bson import ObjectId
from .auth import login_required , Admin
from weasyprint import HTML
import base64

@app.route('/delete_order', methods=['POST'])
@login_required
@Admin
def delete_order():
    product_id = request.form.get('product_id')
    order_to_delete = order.find_one({'product_id': ObjectId(product_id)})
    if order_to_delete:
        order.delete_one({'product_id': ObjectId(product_id)})
        flash('Order has been deleted successfully!', 'success')
    else:
        flash('Order not found.', 'danger')
    return redirect(url_for('orders'))



@app.route('/buy', methods=['POST'])
@login_required
def buy():
    if request.method == 'POST':
        cart_items = cart_collection.find({'email': session.get('email')})
        for cart_item in cart_items:
            product = prod.find_one({'_id': cart_item['product_id']})
            if product:
                order_data = {
                    'product_id': product['_id'],
                    'product_name': product['Pname'],
                    'product_price': product['price'],
                    'quantity': cart_item['quantity'],
                    'username': session['username'],
                    'email': session['email'],
                    'phone': session.get('phone'),  
                    'address': session.get('address'),  
                    'order_date': datetime.now()
                }
                order.insert_one(order_data)
        cart_collection.delete_many({'email': session.get('email')})
        flash('Order added and all items have been bought successfully!', 'success')
        return redirect(url_for('view_cart'))
    return redirect(url_for('home'))

@app.route('/generate_pdf', methods=['POST'])
@login_required
@Admin
def generate_pdf():
    if request.method == 'POST':
	    all_orders = order.find()
	    html = render_template('order_template.html' , languages=LANGUAGES,order=all_orders)
	    pdf = HTML(string=html).write_pdf()
	    response = Response(pdf, content_type='application/pdf')
	    response.headers['Content-Disposition'] = 'inline; filename=output.pdf'
	    return response
    
@app.route('/add_to_cart', methods=['GET', 'POST'])
@login_required
def add_to_cart():
    id=request.form['prodID']
    product = prod.find_one({'_id': ObjectId(id)})
    if request.method == 'POST':
        email = session.get('email')
        quantity = 1   
        quantity = int(request.form.get('quantity', 1)) 
        if product:
            cart_data = {
                'product_id': product['_id'],
                'product_name': product['Pname'],
                'product_price': product['price'],
                'quantity': quantity,
                'email': email  # Include the user's email in the cart data
            }
            cart_collection.insert_one(cart_data)
            msg="your order hase been seccsfuly added to cart "
            return redirect(url_for('viewShop'))
        else:
            msg="Product is not availebale "
            return redirect(url_for('viewShop',msg=msg))
    return redirect(url_for('viewShop'))





@app.route('/product_detail', methods=['GET', 'POST'])
def product_detail():
    if request.method == 'POST':
        id=request.form['prodID']
        product = prod.find_one({'_id': ObjectId(id)})
        if product:
            base64_data = base64.b64encode(gridfs.get(product['id']).read()).decode('utf-8')
            product['image_data'] = 'data:image/jpeg;base64,' + base64_data
            return render_template('detail.html', product=product, languages=LANGUAGES)            
        else:
            flash('Product not found.', 'danger')
            return redirect(url_for('viewShop'))
    return  redirect(url_for("viewShop"))
        

@app.route('/update_quantity', methods=['POST'])
@login_required
def update_quantity():
    if request.method == 'POST':
        id=request.form['prodID']
        quantity = int(request.form.get('quantity', 1))
        cart_collection.update_one({'product_id': ObjectId(id), 'email': session.get('email')}, {'$set': {'quantity': quantity}})
        flash('Quantity updated successfully!', 'success')
        return redirect(url_for('view_cart'))
    return redirect(url_for('viewShop'))


@app.route('/remove_from_cart', methods=['POST'])
@login_required
def remove_from_cart():
    product_id = ObjectId(request.form.get('productId'))
    email = session['email']  
    cart_collection.delete_one({'product_id': product_id, 'email': email})
    flash('Item removed from cart!', 'success')
    return redirect(url_for('view_cart'))

@app.route('/search', methods=['GET', 'POST'])
def search():
    query = request.args.get('query')
    filter_by = request.args.get('filter')
    if query:
        if filter_by:
            results = prod.find({
                '$and': [
                    {'Pname': {'$regex': query, '$options': 'i'}},
                    {'type': {'$regex': filter_by, '$options': 'i'}}
                ]
            })
        else:
            results = prod.find({'Pname': {'$regex': query, '$options': 'i'}})
    else:
        results = prod.find()
    search_results = []
    for result in results:
        search_results.append({
            'Pname': result['Pname'],
            'Pnumber': result['Pnumber'],
            'price': result['price'],
            'quantity': result['quantity'],
            '_id': str(result['_id']) 
        })
    return render_template('search_results.html', results=search_results)


