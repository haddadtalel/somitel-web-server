from flask import render_template , session , request
from web import app , LANGUAGES
from .auth import login_required, Admin

@app.route('/', methods=['GET', 'POST'])
def home():
   if session['language']== 'fr':
      return render_template('home_fr.html', languages=LANGUAGES)
   return render_template('home_en.html', languages=LANGUAGES)

@app.route('/set_language/<lang>', methods=['GET'])
def set_language(lang):
   session['language'] = lang
   return lang
@app.route('/about', methods=['GET', 'POST'])
def about():
   return render_template('about.html', languages=LANGUAGES)


@app.route('/contact', methods=['GET', 'POST'])
def contact():
   return render_template('contact.html', languages=LANGUAGES)


@app.route('/login', methods=['GET', 'POST'])
def login():
   return render_template('login.html', languages=LANGUAGES)

   
@app.route('/signUp', methods=['GET', 'POST'])
def signUp():
   return render_template('sign_up.html', languages=LANGUAGES)   

@app.route('/add', methods=['GET', 'POST'])
@Admin
@login_required
def add():
   return render_template('dashboard.html', languages=LANGUAGES)  


@app.route('/shop', methods=['GET', 'POST'])
def shop():
    return render_template('shop.html')    

@app.route('/order_template', methods=['GET', 'POST'])
@Admin
@login_required
def order_template():
   return render_template('order_template.html', languages=LANGUAGES)    


@app.route('/update_password', methods=['GET', 'POST'])
@login_required
def update_password():
   return render_template('update_password.html', languages=LANGUAGES)    



